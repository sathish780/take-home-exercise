import tempfile
import os
from compare_headers import compare_headers


def run_test(expected_content, actual_content):
    with tempfile.TemporaryDirectory() as temp_dir:
        expected_file = os.path.join(temp_dir, "expected.csv")
        actual_file = os.path.join(temp_dir, "actual.csv")

        with open(expected_file, "w", newline="") as f:
            f.write(expected_content)

        with open(actual_file, "w", newline="") as f:
            f.write(actual_content)

        return compare_headers(expected_file, actual_file)


# Test 1: Identical headers
result = run_test("id,name,amount\n", "id,name,amount\n")
assert result == ([], [], ["id", "name", "amount"], True)
print("Test 1 passed: Identical headers")

# Test 2: One header is missing
result = run_test("id,name,amount\n", "id,name\n")
assert result == (["amount"], [], ["id", "name"], True)
print("Test 2 passed: Missing header")

# Test 3: Extra spaces around headers
result = run_test(" id , name , amount \n", "id,name,amount\n")
assert result == ([], [], ["id", "name", "amount"], True)
print("Test 3 passed: Extra spaces")

# Test 4: Windows line endings
result = run_test("id,name,amount\r\n", "id,name,amount\r\n")
assert result == ([], [], ["id", "name", "amount"], True)
print("Test 4 passed: Windows line endings")

# Test 5: Common headers in a different order
result = run_test("id,name,amount\n", "name,id,amount\n")
assert result == ([], [], ["id", "name", "amount"], False)
print("Test 5 passed: Different header order")

print("\nAll tests passed!")