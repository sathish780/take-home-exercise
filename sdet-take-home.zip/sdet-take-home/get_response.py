import requests

BASE_URL = "https://allproducts"


def test_get_order_status_paid():
    url = f"{BASE_URL}/api/orders/ORD-1001"

    # Send GET request
    response = requests.get(url, timeout=10)

    # Validate HTTP status code
    assert response.status_code == 200, (
        f"Expected 200, got {response.status_code}"
    )

    response_data = response.json()

    # Validate order status
    assert response_data["status"] == "PAID", (
        f"Expected PAID, got {response_data.get('status')}"
    )

    print("API test passed: HTTP 200 and status PAID")
    
test_get_order_status_paid()