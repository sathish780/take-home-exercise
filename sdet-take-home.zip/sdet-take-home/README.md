# CSV Header Comparison Tool

## 1. Language Used
- **Python 3**
- Libraries: `pandas`, `os`, `sys`

---

## 2. How to Run the CSV Comparison Tool
1. Place `compare_headers.py` in your working directory.
2. Ensure you have two CSV files (e.g., `expected_orders.csv` and `actual_orders.csv`).
3. Run the tool from the command line:
   ```bash
   python compare_headers.py expected_orders.csv actual_orders.csv
   The program will print:

Common headers

Headers unique to each file

Validation errors if files are missing, empty, or invalid


# 3. SQL Scenarios: Product Comparison (Yesterday vs Today)

This document explains the SQL queries used to analyze changes between two tables:
- `products_yesterday`
- `products_today`

---

## 1. Why did you use INNER JOIN, LEFT JOIN, NOT EXISTS, or another approach?

- **LEFT JOIN**  
  Used when we want all rows from yesterday’s table, even if they don’t exist today. Example: finding **discontinued products**.  
  👉 Helpful to detect missing records.

- **NOT EXISTS**  
  Used as an **anti-join** to find records that exist in one table but not the other. Example:  
  - Products **new today** (`NOT EXISTS` in yesterday).  
  - Products **missing today** (`NOT EXISTS` in today).  
  👉 Often more readable and efficient for “missing record” checks.

---

## 2. What would change if `product_id` was not unique?

- If `product_id` is **not unique**, joins could produce **duplicate rows**.  
- Example: If `product_id = 1001` appears twice in `products_today`, an `INNER JOIN` with `products_yesterday` would return multiple matches.  
- To fix this, we would need:
  - A **primary key** (e.g., `product_id + product_name` or a surrogate key).  
  - Or use **DISTINCT** / **GROUP BY** to eliminate duplicates.  
- Without uniqueness, comparisons may be misleading because multiple rows could represent the same product.

---

## 3. What issue could happen if `price` or `status` can be NULL?

- **NULL values** complicate comparisons:
  - In SQL, `NULL <> NULL` evaluates to **false** (they are considered unknown, not equal).  
  - A product with `NULL` yesterday and `NULL` today would not be flagged as changed, even though it might be incomplete data.  
  - A product with `NULL` yesterday and a valid value today would be flagged as changed, which may or may not be correct depending on business rules.

## Summary
- **LEFT/RIGHT JOIN** → Detect missing or new records.  
- **NOT EXISTS** → Clean anti-join for new/discontinued products.  
- **Uniqueness of product_id** is critical to avoid duplicates.  
- **NULL handling** must be considered to avoid false negatives/positives in comparisons.

## SQL Answers
- **Sql answers are present in answers.sql file.

# 4. API Test Scenarios

1. Get details for  oder_id "1001" --> return the proper json response for the specific order id with 200 response code
2. Verify oder id field --> 200 OK with correct order id
3. Invalid Method --> Send request with post method and expect 405 error code for invalid method
4. Non-existing order id --> send request with non-existing order id and expecting 404 error code with npt found error
5. Invalid order id format --> send request with invalid order id format(zbc1100) and expecting 400 error code with bad request.

# 5. Assuption Made

1. Python and pandas library is most efficient way to handle excel/csv files.
2. INNER JOIN and NOT EXIST is best way to compare the two tables.
3. Derived both possitive and negative scenarios for API testing.

# 6. AI Usage Statement:

1. AI Agent --> Microsoft Copilot
2. Copilot is used for design test cases, write Python scripts, and draft documentation. Copilot was used to accelerate     development and ensure clarity.

3. AI prompt and responses are captured in AI_TRANSCRIPT.md