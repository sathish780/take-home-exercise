import csv
import sys
import os


def read_headers(file_path):
    # Check whether the file exists
    if not os.path.isfile(file_path):
        raise FileNotFoundError(f"File does not exist: {file_path}")

    with open(file_path, "r", newline="", encoding="utf-8-sig") as file:
        reader = csv.reader(file)
        headers = next(reader, None)

    # Check whether the CSV file is empty
    if headers is None:
        raise ValueError(f"CSV file is empty: {file_path}")

    # Remove whitespace around headers
    headers = [header.strip() for header in headers]

    # Check whether any valid headers exist
    if not headers or not any(headers):
        raise ValueError(f"No valid headers found in: {file_path}")

    return headers


def compare_headers(expected_file, actual_file):
    expected = read_headers(expected_file)
    actual = read_headers(actual_file)

    only_expected = [h for h in expected if h not in actual]
    only_actual = [h for h in actual if h not in expected]

    common = [h for h in expected if h in actual]
    actual_common = [h for h in actual if h in expected]

    same_order = common == actual_common

    return only_expected, only_actual, common, same_order


def main():
    # 1. Check command-line arguments
    if len(sys.argv) != 3:
        print(
            "Error: Missing or invalid file path arguments.\n"
            "Usage: python compare_headers.py "
            "expected_orders.csv actual_orders.csv"
        )
        sys.exit(1)

    expected_file = sys.argv[1]
    actual_file = sys.argv[2]

    try:
        only_expected, only_actual, common, same_order = (
            compare_headers(expected_file, actual_file)
        )

        print(f"Only in {expected_file}:")
        for header in only_expected:
            print(header)

        print(f"\nOnly in {actual_file}:")
        for header in only_actual:
            print(header)

        print("\nCommon headers:")
        for header in common:
            print(header)

        print("\nCommon headers in same relative order:")
        print(str(same_order).lower())

    except (FileNotFoundError, ValueError, PermissionError, csv.Error) as error:
        print(f"Error: {error}")
        sys.exit(1)


if __name__ == "__main__":
    main()