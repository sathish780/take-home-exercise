I have a two tables,
Table: products_yesterday
product_id	product_name	price	status
1001	    Coffee Mug	    12.50	ACTIVE
1002	    Laptop Stand	38.00	ACTIVE
1003	    Wireless Mouse	19.99	ACTIVE
1004	    Old Keyboard	29.99	DISCONTINUED
1005	    Notebook	    4.50	ACTIVE
1008	    Desk Lamp	    24.00	ACTIVE

Table: products_today
product_id	product_name	price	status
1001	    Coffee Mug	    12.50	ACTIVE
1002	    Laptop Stand	35.00	ACTIVE
1003	    Wireless Mouse	21.99	ACTIVE
1005	    Notebook	    4.50	INACTIVE
1006	    Webcam	        59.00	ACTIVE
1007	    USB Cable	    7.99	ACTIVE
1008	    Desk Lamp	    24.00	ACTIVE

Task1: Price Change
SELECT 
    y.product_id,
    y.product_name,
    y.price AS old_price,
    t.price AS new_price
FROM products_yesterday y
LEFT JOIN products_today t
    ON y.product_id = t.product_id
WHERE t.price IS NOT NULL AND y.price <> t.price;


Output:
product_id	product_name	old_price	new_price
1002	    Laptop Stand	38.00	    35.00
1003	    Wireless Mouse	19.99	    21.99


Task2: New product

SELECT 
    t.product_id,
    t.product_name,
    t.price,
    t.status
FROM products_today t
WHERE NOT EXISTS (
    SELECT 1 
    FROM products_yesterday y
    WHERE y.product_id = t.product_id
);

Output:

product_id	product_name	price	status
1006	    Webcam	        59.00	ACTIVE
1007	    USB Cable	    7.99	ACTIVE

Task3: Missing product

SELECT 
    y.product_id,
    y.product_name,
    y.price,
    y.status
FROM products_yesterday y
WHERE NOT EXISTS (
    SELECT 1 
    FROM products_today t
    WHERE t.product_id = y.product_id
);

Output:

product_id	product_name	price	status
1004	    Old Keyboard	29.99	DISCONTINUED

Task4: Status Changed

SELECT
    y.product_id,
    y.product_name,
    y.status AS old_status,
    t.status AS new_status
FROM products_yesterday y
LEFT JOIN products_today t 
    ON t.product_id = y.product_id
WHERE y.status <> t.status;

Output:

product_id	product_name	old_status	new_status
1005	    Notebook	    ACTIVE	    INACTIVE